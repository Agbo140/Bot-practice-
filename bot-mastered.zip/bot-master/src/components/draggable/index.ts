import Draggable from './draggable';
import './draggable.scss';

export default Draggable;
