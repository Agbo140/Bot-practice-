import BlocklyLoading from './blockly-loading';
import './blockly-loading.scss';

export default BlocklyLoading;
