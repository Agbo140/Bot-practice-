import LoadModal from './load-modal';
import './load-modal.scss';

export default LoadModal;
