import Tabs from './tabs';
import './tabs.scss';

export default Tabs;
