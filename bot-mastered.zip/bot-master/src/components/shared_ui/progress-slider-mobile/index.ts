import ProgressSliderMobile from './progress-slider-mobile';
import './progress-slider-mobile.scss';

export default ProgressSliderMobile;
