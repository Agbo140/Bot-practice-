import ThemedScrollbars from './themed-scrollbars';
import './themed-scrollbars.scss';

export default ThemedScrollbars;
