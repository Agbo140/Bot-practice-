import MobileWrapper from './mobile-wrapper';
import './mobile-wrapper.scss';

export default MobileWrapper;
