import InputWithCheckBox from './input-with-checkbox';
import './input-with-checkbox.scss';

export default InputWithCheckBox;
