import Dialog from './dialog';
import './dialog.scss';

export default Dialog;
