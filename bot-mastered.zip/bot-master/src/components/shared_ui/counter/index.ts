import Counter from './counter';
import './counter.scss';

export default Counter;
