import WalletIcon from './wallet-icon';

export { WalletIcon };
