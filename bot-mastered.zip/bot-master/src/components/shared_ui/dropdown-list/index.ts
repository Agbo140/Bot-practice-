import DropdownList, { TItem } from './dropdown-list';
import './dropdown-list.scss';

export type { TItem };
export default DropdownList;
