import Input, { TInputProps } from './input';
import './input.scss';

export type { TInputProps };
export default Input;
