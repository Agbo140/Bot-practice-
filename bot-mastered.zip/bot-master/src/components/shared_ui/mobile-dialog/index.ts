import MobileDialog from './mobile-dialog';
import './mobile-dialog.scss';

export default MobileDialog;
