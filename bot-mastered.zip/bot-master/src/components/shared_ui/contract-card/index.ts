import ContractCard from './contract-card';
import './contract-card.scss';

export default ContractCard;
