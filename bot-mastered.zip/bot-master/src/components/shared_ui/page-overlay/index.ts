import PageOverlay from './page-overlay';
import './page-overlay.scss';

export default PageOverlay;
