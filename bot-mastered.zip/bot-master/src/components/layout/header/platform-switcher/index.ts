import PlatformSwitcher from './platform-switcher';

export default PlatformSwitcher;
