export * from './browser_detect';
