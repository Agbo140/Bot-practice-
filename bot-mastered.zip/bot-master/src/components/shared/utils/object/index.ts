export { default as cloneThorough } from './clone';
export * from './object';
