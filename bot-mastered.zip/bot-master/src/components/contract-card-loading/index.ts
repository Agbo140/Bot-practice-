import ContractCardLoader from './contract-card-loading';

export default ContractCardLoader;
