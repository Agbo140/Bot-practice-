import SSOLoader from './sso-loader';
import './sso-loader.scss';

export default SSOLoader;
